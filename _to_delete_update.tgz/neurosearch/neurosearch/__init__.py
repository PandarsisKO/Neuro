"""Neuro Search."""

__version__ = "0.12.2"
